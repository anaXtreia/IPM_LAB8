<template >
  <div id="app">
    <img alt="Vue logo" src="@/assets/images/logo.png">
    <h1>Welcome to Your LAB8_10 Vue App</h1>
  </div>
</template>

<script>

</script>

<style scoped>
	#app {
	font-family: Avenir, Helvetica, Arial, sans-serif;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	text-align: center;
	color: #2c3e50;
	margin-top: 100px;
	}
</style>