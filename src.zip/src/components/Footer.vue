<template>
    <div class="footer">
        <span class="text-muted">© 2022 IPM</span>
        <span class="text-muted author">Designed by Ana Estreia</span>
    </div>

</template>

<style scoped>
.footer {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    width: 100%;
}

.author {
    float: right;
}
</style>