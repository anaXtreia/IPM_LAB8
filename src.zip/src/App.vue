<template>
  <div id="app" class="small-container">
    <router-view/>
  </div>
</template>

<style>
</style>